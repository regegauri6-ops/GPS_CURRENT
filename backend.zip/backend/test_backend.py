import requests
import json

# Configuration
BASE_URL = "http://localhost:8000"
ENDPOINT = "/places/nearby"

# Coordinates (Using Berlin, Germany as a test location likely to have hospitals)
# You can change this to your local coordinates.
LAT = 52.5200
LON = 13.4050
RADIUS = 2000 # meters

def test_nearby_places():
    print(f"Testing {BASE_URL}{ENDPOINT}...")
    print(f"Params: Lat={LAT}, Lon={LON}, Radius={RADIUS}")
    
    try:
        response = requests.get(
            f"{BASE_URL}{ENDPOINT}", 
            params={"latitude": LAT, "longitude": LON, "radius": RADIUS}
        )
        
        print(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            results = data.get("results", [])
            print(f"Success! Found {len(results)} places.")
            for i, place in enumerate(results[:3]): # Print first 3
                print(f"  {i+1}. {place['name']} ({place['type']})")
                print(f"     Address: {place['address']}")
        else:
            print("Error Response:")
            print(response.text)
            
    except Exception as e:
        print(f"Failed to connect: {e}")
        print("Make sure the backend is running: uvicorn main:app --reload")

if __name__ == "__main__":
    test_nearby_places()
