from fastapi import APIRouter, Depends, HTTPException, Query
from typing import List
import schemas
from services import places_service

router = APIRouter(
    prefix="/places",
    tags=["places"]
)

@router.get("/nearby", response_model=schemas.PlacesResponse)
async def get_nearby_places(
    latitude: float, 
    longitude: float,
    radius: int = Query(1500, description="Search radius in meters")
):
    """
    Get nearby doctors, clinics, hospitals.
    Uses generic service that switches between Mock and Real API based on .env
    """
    results = await places_service.get_nearby_places(latitude, longitude, radius)
    return schemas.PlacesResponse(results=results)
