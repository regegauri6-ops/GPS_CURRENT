from sqlalchemy.orm import Session
import models, schemas
import math

def create_or_update_location(db: Session, location: schemas.LocationCreate):
    # For this single-user app demo, we'll store just one location or always get the last one.
    db_location = db.query(models.UserLocation).first()
    if db_location:
         db_location.latitude = location.latitude
         db_location.longitude = location.longitude
         # updated_at handles itself via onupdate=func.now()
    else:
         db_location = models.UserLocation(latitude=location.latitude, longitude=location.longitude)
         db.add(db_location)
    
    db.commit()
    db.refresh(db_location)
    return db_location

def get_latest_location(db: Session):
    return db.query(models.UserLocation).order_by(models.UserLocation.created_at.desc()).first()

# --- Caching Logic ---

def haversine_distance(lat1, lon1, lat2, lon2):
    R = 6371000  # Earth radius in meters
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    a = math.sin(delta_phi / 2)**2 + \
        math.cos(phi1) * math.cos(phi2) * \
        math.sin(delta_lambda / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c

def get_cached_places(db: Session, lat: float, lon: float, radius: int):
    # SQLite doesn't have efficient geospatial indexing built-in without extra modules.
    # We will use a bounding box filter first for speed, then refine with Haversine.
    
    # 1 degree lat ~= 111km. 1 degree lon ~= 111km * cos(lat)
    # Simple bounding box approximation
    lat_delta = radius / 111000.0
    lon_delta = radius / (111000.0 * math.cos(math.radians(lat)))
    
    min_lat = lat - lat_delta
    max_lat = lat + lat_delta
    min_lon = lon - lon_delta
    max_lon = lon + lon_delta
    
    candidates = db.query(models.CachedPlace).filter(
        models.CachedPlace.latitude.between(min_lat, max_lat),
        models.CachedPlace.longitude.between(min_lon, max_lon)
    ).all()
    
    results = []
    for place in candidates:
        dist = haversine_distance(lat, lon, place.latitude, place.longitude)
        if dist <= radius:
            results.append(place)
            
    return results

def cache_places(db: Session, places: list[schemas.Place]):
    for p in places:
        # Check if exists by osm_id (we need to treat generated ID as OSM ID for now or create one)
        # Since Schema Place doesn't have ID, we'll try to find by Name + Lat/Lng or simple upsert logic
        # For this demo, let's assume we can rely on verifying existence by lat/lng/name
        
        # NOTE: Ideally schemas.Place should carry the OSM ID from the service. 
        # But to keep schemas simple as per instructions, we might generate a pseudo-ID or just check duplicates.
        # Let's check duplicates by Name + Type
        existing = db.query(models.CachedPlace).filter(
            models.CachedPlace.name == p.name,
            models.CachedPlace.type == p.type,
            models.CachedPlace.latitude == p.latitude,
            models.CachedPlace.longitude == p.longitude
        ).first()
        
        if existing:
            # Refresh timestamp and data
            existing.cached_at = func.now()
        else:
            new_place = models.CachedPlace(
                osm_id=f"temp_{p.name}_{p.latitude}", # accurate OSM ID preferred but requires schema change passed from service
                name=p.name,
                type=p.type,
                latitude=p.latitude,
                longitude=p.longitude,
                address=p.address,
                phone=p.phone_number,
                # maps_link is dynamic usually, but we can store if needed or re-generate
            )
            db.add(new_place)
    
    db.commit()
