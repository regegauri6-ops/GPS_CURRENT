import os
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

from database import engine, Base
from routers import location, places

# Load .env
load_dotenv()

# Create DB Tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="GPS Location App",
    description="API for storing user location and finding nearby places",
    version="1.0.0"
)

# CORS Configuration
# Allow all origins for simplicity in development/mobile testing
origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include Routers
app.include_router(location.router)
app.include_router(places.router)

@app.get("/")
def root():
    return {"message": "GPS App API is running"}

if __name__ == "__main__":
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", 8000))
    print(f"Starting server on {host}:{port}")
    uvicorn.run("backend.main:app", host=host, port=port, reload=True)
